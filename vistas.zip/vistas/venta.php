<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();

date_default_timezone_set('America/Lima');

if (!isset($_SESSION["nombre"])) {
  header("Location: ../index.php");
} else {
  require 'modulos/header.php';

  if ($_SESSION['ventas'] == 1) {
?>

    <style type="text/css">
      body {
        font-family: Arial;
        font-size: 10pt;
      }

      .center {
        z-index: 1000;
        margin: 300px auto;
        padding: 10px;
        width: 130px;
        background-color: White;
        border-radius: 10px;
        filter: alpha(opacity=100);
        opacity: 1;
        -moz-opacity: 1;
      }

      .center img {
        height: 128px;
        width: 128px;
      }
    </style>

    <!--Contenido-->
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Main content -->
      <section class="content-header">
        <br>
        <ol class="breadcrumb">

          <li><a href="inicio.php"><i class="fa fa-dashboard"></i> Inicio</a></li>

          <li class="active">Administrar ventas</li>

        </ol>
      </section>
      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default" style="border-color: #666; border-width: 3px; border-style: double;">

              <div class="panel-heading">
                <div class="box-header with-border">
                  <h1 class="box-title">Ventas</h1>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse">
                      <i class="fa fa-minus"></i>
                    </button>
                    <button class="btn btn-box-tool" data-widget="remove">
                      <i class="fa fa-times"></i>
                    </button>
                  </div>

                </div>
              </div>

              <!-- /.box-header -->
              <!-- centro -->
              <div class="panel-body table-responsive" id="listadoregistros">
                <button class="btn btn-primary" id="btnagregar" onclick="mostrarform(true)"><i class="fa fa-plus"> Nuevo</i></button>
                <button class="btn btn-danger" id="btnGenerarReporte" onclick="generarReporte();"><i class="fa fa-file"></i> Reporte</button>
                <br><br>
                <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <label>Fecha Inicio</label>
                  <div class="input-group date">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="date" class="form-control" name="fecha_inicio" id="fecha_inicio" value="<?php echo date("Y-m-d"); ?>">
                  </div>
                </div>

                <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <label>Fecha Fin</label>
                  <div class="input-group date">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input type="date" class="form-control" name="fecha_fin" id="fecha_fin" value="<?php echo date("Y-m-d"); ?>">
                  </div>
                </div>

                <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <label>Almacén:</label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-laptop"></i></span>
                    <select id="idsucursal2" name="idsucursal2" class="form-control selectpicker" data-live-search="true">
                    </select>
                  </div>
                </div>

                <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <label>Estado:</label>
                  <select id="estado" name="estado" class="form-control selectpicker" data-live-search="true" required>
                    <option value="Todos">Todos</option>
                    <option value="Aceptado">Aceptado</option>
                    <option value="Por Enviar">Por Enviar</option>
                    <option value="Nota Credito">Nota de Crédito</option>
                    <option value="Rechazado">Rechazado</option>
                  </select>
                </div>
                <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover dataTable" cellpadding="0" cellspacing="0" aria-describedby="tblIngresos_info" width="100%" role="grid" style="width: 100%;">
                  <thead>
                    <th>ID</th>
                    <th>Cliente / N° Documento</th>
                    <th>Sucursal</th>
                    <th>Número</th>
                    <th>Total Venta</th>
                    <th>Tipo Pago</th>
                    <th>Estado</th>
                    <th width="70px;">Sunat</th>
                    <th style="text-align: center;"><i class="fa fa-shield" aria-hidden="true" title="Comprobar estado"></i></th>
                    <th width="180px;">Acciones</th>
                  </thead>
                  <tbody>
                  </tbody>
                  <tfoot>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th>Sucursal</th>
                    <th>Número</th>
                    <th>Total Venta</th>
                    <th>Tipo Pago</th>
                    <th>Estado</th>
                    <th>Sunat</th>
                    <th></th>
                    <th>Acciones</th>
                  </tfoot>
                </table>
              </div>
              <div class="panel-body" id="formularioregistros">
                <form name="formulario" id="formulario" method="POST">

                  <input type="hidden" name="tipo" id="tipo" value="venta">

                  <div class="col-lg-12" style="padding-left: 0px;">

                    <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <label>Almacén:</label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-laptop"></i></span>
                        <select id="idsucursal" name="idsucursal" class="form-control selectpicker" data-live-search="true">
                        </select>
                      </div>
                    </div>

                  </div>

                  <div class="form-group col-lg-6 col-md-4 col-sm-4 col-xs-12">
                    <label>Personal:</label>
                    <div class="input-group">

                      <span class="input-group-addon"><i class="fa fa-user"></i></span>

                      <select id="idpersonal" name="idpersonal" class="form-control selectpicker" data-live-search="true" title="Seleccione Trabajador" required></select>

                    </div>
                  </div>

                  <div class="form-group col-lg-6 col-md-4 col-sm-4 col-xs-12">
                    <label>Cliente:</label>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-users"></i></span>
                      <select id="idcliente" name="idcliente" class="form-control selectpicker" data-live-search="true">
                      </select>
                      <a class="input-group-addon" style="cursor: pointer;" data-toggle="modal" data-target="#ModalClientes" title="Agregar Nuevo Cliente"><i class="fa fa-plus"></i></a>

                    </div>
                  </div>


                  <div class="form-group col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <label>Fecha:</label>
                    <div class="input-group date">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                      <input style="border-color: #99C0E7; text-align:center" class="form-control pull-right" type="date" name="fecha" id="fecha" required>
                    </div>
                  </div>

                  <div class="form-group col-lg-3 col-md-4 col-sm-4 col-xs-12">

                    <label>Tipo Comprobante:</label>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-file"></i></span>
                      <select name="tipo_comprobante" id="tipo_comprobante" class="form-control selectpicker" onchange="limpiarDetalle(this.value);" required>
                      </select>
                    </div>
                  </div>

                  <div class="form-group col-lg-2 col-md-3 col-sm-6 col-xs-12">
                    <label>Serie:</label>
                    <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" name="serie_comprobante" id="serie_comprobante" maxlength="7" placeholder="Serie" readonly="">
                  </div>

                  <div class="form-group col-lg-2 col-md-3 col-sm-6 col-xs-12">
                    <label>Número:</label>
                    <input style="border-color: #99C0E7; text-align:center" type="text" class="form-control" name="num_comprobante" id="num_comprobante" maxlength="10" placeholder="Número" required="" readonly="">
                  </div>

                  <div class="form-group col-lg-2 col-md-2 col-sm-6 col-xs-12">
                    <label>Impuesto:</label>
                    <div class="input-group date">
                      <div class="input-group-addon">%
                      </div>
                      <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" name="impuesto" id="impuesto" required="" readonly="">
                    </div>
                  </div>

                  <div class="form-group col-lg-4 col-md-3 col-sm-3 col-xs-12">
                    <label><i class="fa fa-barcode"></i> Códig de barras:</label>
                    <div class="input-group">
                      <span class="input-group-addon">
                        <i class="fa fa-search"></i>
                      </span>
                      <input style="background: #fff" autofocus="" class="form-control" id="idCodigoBarra" name="idCodigoBarra" placeholder="Codigo de Barras Aquí, Venta Rápida" type="text" onkeypress="buscarProductoCod(event, this.value)">

                    </div>

                  </div>

                  <div class="form-group col-lg-6 col-md-3 col-sm-3 col-xs-12" style="padding-top: 24px;">
                    <a data-toggle="modal" href="#myModal">
                      <button id="btnAgregarArt" type="button" class="btn btn-danger" onclick="listarArticulos();"> <span class="fa fa-search"></span> Seleccionar Productos</button>
                    </a>
                    <a data-toggle="modal" href="#myModal2">
                      <button id="btnAgregarArt2" type="button" class="btn btn-primary" onclick="listarArticulos2();"> <span class="fa fa-search"></span> Seleccionar Servicios</button>
                    </a>
                  </div>

                  <div class="col-lg-12" style="padding-left: 0px;">

                    <div class="form-group col-lg-3 col-md-4 col-sm-4 col-xs-12">
                      <label>Importar Cotizaciones:</label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-file"></i></span>
                        <select id="comprobanteReferencia" name="comprobanteReferencia" class="form-control selectpicker" data-live-search="true" onchange="mostrarE();" title="Seleccionar Comprobante">
                        </select>

                      </div>
                    </div>

                  </div>

                  <div class="col-lg-12 modal-body table-responsive">
                    <table id="detalles" class="table table-striped table-bordered table-condensed table-hover" width="100%">
                      <thead>
                        <th style="text-align:center;width: 400px;">Producto</th>
                        <th>UM</th>
                        <th>Cantidad</th>
                        <th>Precio Venta</th>
                        <th>Descuento</th>
                        <th>Stock</th>
                        <th>Subtotal</th>
                        <th>Opciones</th>
                      </thead>
                      <tfoot>
                      </tfoot>
                      <tbody>

                      </tbody>
                    </table>

                  </div>

                  <div class="col-sm-4 col-sm-offset-3 col-lg-8 col-lg-offset-4 main">
                    <div class="row">
                      <div class="col-lg-4 left">
                        <div class="input-group has-error">
                          <div id="Subtotal" class="input-group-addon">Sub Total:</div>

                          <h8 align="center" class="form-control input-lg" id="most_total" readonly></h8>

                          <input type="hidden" name="most_total2" id="most_total2">


                        </div>
                      </div>

                      <div class="col-lg-4 left  has-error">
                        <div class="input-group">
                          <div id="IGV" class="input-group-addon">S/ IGV 18.00%:</div>
                          <h8 align="center" class="form-control input-lg" id="most_imp" placeholder="Impuesto" readonly></h8>

                        </div>

                      </div>

                      <div class="col-lg-4 left has-error">
                        <div class="input-group">
                          <div id="Total" class="input-group-addon">Total:</div>
                          <h8 align="center" class="form-control input-lg" id="total" readonly></h8>

                          <input type="hidden" name="total_venta" id="total_venta">



                        </div>
                      </div>

                    </div>
                  </div>

                  <div class="row">

                    <div class="form-group col-lg-2" style="padding-left: 28px;">

                      <label>¿Venta al crédito?</label>
                      <div class="input-group">
                        <select id="tipopago" name="tipopago" class="form-control" data-live-search="true" required>
                          <option value="No">No</option>
                          <option value="Si">Sí</option>
                        </select>
                      </div>

                    </div>

                    <div class="form-group col-lg-4" style="padding-left: 28px;">

                      <label>Forma de pago:</label>
                      <div class="input-group col-lg-12">
                        <select id="formapago" name="formapago" class="form-control" data-live-search="true" required>
                          <option value="Efectivo">Efectivo</option>
                          <option value="Transferencia">Transferencia bancaria</option>
                          <option value="Tarjeta">Tarjeta POS</option>
                          <option value="Deposito">Depósito</option>
                          <option value="Yape">Yape</option>
                          <option value="Plin">Plin</option>
                          <option value="Reposicion">Reposición</option>
                          <option value="Costo0">Costo 0</option>
                        </select>
                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="form-group col-lg-2" style="padding-left: 28px; display: none;" id="n1">

                      <label>Fecha de Pago:</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="date" class="form-control" id="fechaOperacion" name="fechaOperacion" value="<?php echo date("Y-m-d"); ?>">
                      </div>

                    </div>

                    <div class="form-group col-lg-2" style="padding-left: 28px; display: none;" id="n2">

                      <label>Monto Pagado:</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" id="montoPagado" name="montoPagado" value="0" onkeyup="calcularDeuda();">
                      </div>

                    </div>

                    <div class="form-group col-lg-2" style="padding-left: 50px; display: none;" id="n3">

                      <label>Monto Deuda:</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" id="montoDeuda" name="montoDeuda" readonly="">
                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="form-group col-lg-2" style="padding-left: 28px; display: none;" id="n6">

                      <label># de Operación:</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" id="nroOperacion" name="nroOperacion">
                      </div>

                    </div>

                    <div class="form-group col-lg-2" style="padding-left: 28px; display: none;" id="fechadeposito">

                      <label>Fecha Depósito:</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="date" class="form-control" id="fechaDepostivo" name="fechaDepostivo">
                      </div>

                    </div>

                    <div class="form-group col-lg-2" style="padding-left: 50px; display: none;" id="banco">

                      <label>Banco:</label>
                      <div class="input-group col-lg-12">
                      <select id="banco" name="banco" class="form-control selectpicker" data-live-search="true" title="Seleccione Banco">
                          <option value="BCP">BCP</option>
                          <option value="BBVA">BBVA</option>
                          <option value="INTERBANK">INTERBANK</option>
                        </select>
                      </div>
                    </div>

                  </div>

                  <div class="row">

                    <div class="form-group col-lg-2" style="padding-left: 28px;">

                      <label>Descuento:</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" name="porcentaje" id="porcentaje" maxlength="7" placeholder="Descuento" onkeyup="calcularPorcentaje();" disabled="disabled">
                      </div>

                    </div>

                    <div class="form-group col-lg-2" style="padding-left: 28px;">

                      <label>Total Recibido S/.</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" id="totalrecibido" name="totalrecibido" placeholder="Monto recibido" onkeyup="calcularVuelto();">
                      </div>

                    </div>

                    <div class="form-group col-lg-2" style="padding-left: 50px;">

                      <label>Vuelto S/.</label>
                      <div class="input-group">
                        <input style="border-color: #FFC7BB; text-align:center" type="text" class="form-control" id="vuelto" name="vuelto" readonly="">
                      </div>

                    </div>

                  </div>

                  <div class="form-group col-lg-6 col-md-2 col-sm-6 col-xs-12">
                    <label>Observaciones:</label>
                    <textarea style="border-color: #FFC7BB;" type="text" class="form-control" name="observaciones" id="observaciones" rows="4" cols="50">
                                                </textarea>
                  </div>

                  <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <br>
                    <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i> Guardar</button>

                    <button id="btnCancelar" class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-remove"></i> Cancelar</button>
                  </div>

                </form>
              </div>
              <!--Fin centro -->
            </div><!-- /.box -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </section><!-- /.content -->

    </div><!-- /.content-wrapper -->
    <!--Fin-Contenido-->

    <!-- Modal -->
    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content panel panel-primary">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">Seleccione un Servicio</h4>
          </div>
          <div class="modal-body table-responsive">
            <table id="tblarticulos2" class="table table-striped table-bordered table-condensed table-hover" width="100%">
              <thead>
                <th style="width:10px">Opciones</th>
                <th>Nombre</th>
                <th>Fecha Vencimiento</th>
                <th>UM</th>
                <th>Categoria</th>
                <th>Stock</th>
                <th>Precio Venta</th>
                <th style="width:40px">Descripción</th>
              </thead>
              <tbody>

              </tbody>
              <tfoot>
                <th style="width:10px">Opciones</th>
                <th>Nombre</th>
                <th>Fecha Vencimiento</th>
                <th>UM</th>
                <th>Categoria</th>
                <th>Stock</th>
                <th>Precio Venta</th>
                <th style="width:40px">Descripción</th>
              </tfoot>
            </table>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Fin modal -->

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content panel panel-primary">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">Seleccione un Producto</h4>
          </div>

          <div class="modal-body table-responsive">
            <table id="tblarticulos" class="table table-striped table-bordered table-condensed table-hover" width="100%">
              <thead>
                <th style="width:10px">Opciones</th>
                <th>Nombre</th>
                <th>UM</th>
                <th>Categoria</th>
                <th>Stock</th>
                <th>P. Venta</th>
                <th>P. Compra</th>
              </thead>
              <tbody>

              </tbody>
              <tfoot>
                <th style="width:10px">Opciones</th>
                <th>Nombre</th>
                <th>UM</th>
                <th>Categoria</th>
                <th>Stock</th>
                <th>P. Venta</th>
                <th>P. Compra</th>
              </tfoot>
            </table>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Fin modal -->

    <!-- Modal -->
    <div class="modal fade" id="ModalClientes" tabindex="-1" role="dialog">

      <div class="modal-dialog">

        <div class="modal-content">
          <!-- form -->
          <form class="form-horizontal" role="form" name="formularioClientes" id="formularioClientes" method="POST">

            <div class="modal-header" style="background:#3c8dbc; color:white">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="limpiarCliente()">&times;</button>
              <h4 class="modal-title">
                Clientes</h4>
            </div>

            <div class="modal-body panel-body" style="padding: 20px">

              <div class="form-group">

                <label for="name" class="col-sm-2 control-label">Tipo Documento: </label>
                <div class="col-sm-4">
                  <select class="form-control select-picker" name="tipo_documento" id="tipo_documento" required>
                    <option value="DNI">DNI</option>
                    <option value="RUC">RUC</option>
                    <option value="CEDULA">CEDULA</option>
                  </select>
                </div>

                <div class="col-sm-6">

                  <div class="input-group">
                    <input type="text" class="form-control" name="num_documento" id="num_documento" maxlength="20" placeholder="Documento">
                    <a class="input-group-addon btn-primary" style="cursor: pointer;" id="Buscar_Cliente" onclick="BuscarCliente()" title="Buscar Cliente" type="button"><i class="fa fa-search"></i></a>

                    <a class="input-group-addon btn-primary hide" id="cargando" style="cursor: pointer;" title="Cargando" type="button">
                      <i><img src="../files/plantilla/cargando.gif" width="15px"></i>
                    </a>

                  </div>

                </div>

              </div>

              <div class="form-group">

                <label for="name" class="col-sm-2 control-label">Nombre:</label>
                <div class="col-sm-10">
                  <input type="hidden" name="idpersona" id="idpersona">
                  <input type="hidden" name="tipo_persona" id="tipo_persona" value="Cliente">
                  <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Nombre del Cliente" required>
                </div>

              </div>

              <div class="form-group">

                <label for="name" class="col-sm-2 control-label">Dirección: </label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="direccion" id="direccion" maxlength="70" placeholder="Dirección">
                  Estado:<label for="" id="estado2">-</label>
                  Condición:<label for="" id="condicion">-</label>
                </div>
              </div>

              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Teléfono:</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Teléfono">
                </div>

                <label for="name" class="col-sm-2 control-label">Email:</label>
                <div class="col-sm-4">
                  <input type="email" class="form-control" name="email" id="email" maxlength="50" placeholder="Email">
                </div>
              </div>

              <div class="form-group col-12">

                <label for="name" class="col-sm-2 control-label">Fecha de Nacimiento:</label>
                <div class="col-sm-4">
                  <input style="border-color: #99C0E7; text-align:center" class="form-control pull-right" type="date" name="fecha_hora" id="fecha_hora">
                </div>

              </div>

            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger pull-left" onclick="limpiarCliente()" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
              <button class="btn btn-primary" id="btnGuardarClientes"><i class="fa fa-save"></i> Guardar</button>
            </div>

          </form>
        </div>
      </div>
    </div>
    <!-- Fin modal -->
    <script>
      window.addEventListener("keyup", checkKeyPress, false);

      function checkKeyPress(key) {
        if (key.keyCode == "113") {
          //alert("si se");
          window.open('../vistas/keyboard.php', '_blank');
        }
      }
    </script>
    <!-- Modal -->
    <div id="getCodeModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content panel panel-primary">

          <div class="modal-header panel-heading">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><span id="titulo-formulario">Vista</span> de Venta</h4>
          </div>
          <div class="modal-body panel-body">
            <input type="hidden" id="txtCodigoSeleccionado">

            <div class="form-group col-lg-5">
              <label class="col-form-label">Cliente (*)</label>
              <input class="form-control" type="hidden" name="idventam" id="idventam">
              <input class="form-control" type="text" name="cliente" id="cliente" maxlength="7" readonly>
            </div>
            <div class="form-group col-lg-3">
              <label class="col-form-label">Personal (*)</label>
              <input type="text" class="form-control" id="nuevoVendedor" value="<?php echo $_SESSION["nombre"]; ?>" readonly>
            </div>
            <div class="form-group col-lg-4">
              <label class="col-form-label">Fecha (*)</label>
              <input class="form-control pull-right" type="text" name="fecha_horam" id="fecha_horam" readonly>
            </div>
            <div class="form-group col-lg-3">
              <label class="col-form-label">Comprobante (*)</label>
              <input class="form-control" type="text" name="tipo_comprobantem" id="tipo_comprobantem" maxlength="7" readonly>
            </div>
            <div class="form-group col-lg-3">
              <label class="col-form-label">Serie (*)</label>
              <input class="form-control" type="text" name="serie_comprobantem" id="serie_comprobantem" maxlength="7" readonly>
            </div>
            <div class="form-group col-lg-3">
              <label class="col-form-label">Número (*)</label>
              <input class="form-control" type="text" name="num_comprobantem" id="num_comprobantem" maxlength="10" readonly>
            </div>
            <div class="form-group col-lg-3">
              <div class="input-group">
                <label class="col-form-label">Impuesto (*)</label>
                <input class="form-control" type="text" name="impuestom" id="impuestom" readonly>
              </div>
            </div>

            <div class="form-group col-lg-3">
              <div class="input-group">
                <label class="col-form-label">Forma Pago (*)</label>
                <input class="form-control" type="text" name="formapagom" id="formapagom" readonly>
              </div>
            </div>

            <div class="form-group col-lg-3">
              <div class="input-group">
                <label class="col-form-label">Número de Operación (*)</label>
                <input class="form-control" type="text" name="nrooperacionm" id="nrooperacionm" readonly>
              </div>
            </div>

            <div class="form-group col-lg-3">
              <div class="input-group">
                <label class="col-form-label">Fecha de Depósito (*)</label>
                <input class="form-control" type="text" name="fechadeposito" id="fechadeposito" readonly>
              </div>
            </div>

            <div class="form-group col-lg-3">
              <label>Estado:</label>
              <select id="estadoLista" name="estadoLista" class="form-control selectpicker" data-live-search="true" onchange="cambiarEstado(this.value);" required>
                <option value="TERMINADO">TERMINADO</option>
                <option value="ENTREGADO">ENTREGADO</option>
              </select>
            </div>

            <div class="form-group col-lg-12 col-md-12 col-xs-12">
              <table id="detallesm" class="table table-striped table-bordered table-condensed table-hover" width="100%">
                <tbody>

                </tbody>
              </table>
            </div>
          </div>
          <div class="modal-footer panel-footer">
            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal"><i class="fa fa-times"></i> Cancelar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Fin modal -->

    <div class="modal" style=" display : none">
      <div class="center">
        <img alt="" src="../files/plantilla/loading-page.gif" />
      </div>
    </div>

    </body>

    </html>
    <!-- Fin modal -->

    <script>
      var elem = document.querySelector('.js-switch');
      var init = new Switchery(elem, {

        color: 'red',
        secondaryColor: 'white',
        jackColor: '#fff',
        jackSecondaryColor: null,
        className: 'switchery',
        disabled: false,
        disabledOpacity: 0.5,
        speed: '0.4s',
        size: 'small'

      });

      $("iframe").each(function() {
        var src = $(this).attr('src');
        $(this).attr('src', src);
      });
    </script>



  <?php
  } else {
    require 'noacceso.php';
  }

  require 'modulos/footer.php';
  ?>
  <script type="text/javascript" src="js/venta.js"></script>
  <script type="text/javascript" src="js/stocksbajos.js"></script>
<?php
}
ob_end_flush();
?>